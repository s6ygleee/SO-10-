(* Paclet Info File *)

(* created 2014/12/18 *)

Paclet[
    Name -> "Susyno",
    Version -> "3.6.0",
    MathematicaVersion -> "7+",
    Extensions -> 
        {
            {"Documentation", Language -> "English", MainPage -> "Tutorials/SusynoTutorial"}
        }
]


